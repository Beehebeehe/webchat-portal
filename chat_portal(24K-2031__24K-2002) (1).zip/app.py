import os
import threading
import io
import ftplib
import uuid
import time
import json
from flask import Flask, render_template, request, session, redirect, url_for, send_file, jsonify
from flask_socketio import SocketIO, emit
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super_secret_key_12345'
socketio = SocketIO(app, cors_allowed_origins="*")

FTP_HOST = "127.0.0.1"
FTP_PORT = 2121
FTP_USER = "user"
FTP_PASS = "12345"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FTP_STORAGE = os.path.join(BASE_DIR, 'ftp_storage')
os.makedirs(FTP_STORAGE, exist_ok=True)
DB_FILE = os.path.join(BASE_DIR, 'database.json')

# In-memory session tracking
users = {}  # {session_id: username}

# Persistent Database
messages_db = []
groups = {}
registered_users = {} # {username: {'email': email, 'password': hashed_pw}}

def load_db():
    global messages_db, groups, registered_users
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r') as f:
                data = json.load(f)
                messages_db = data.get('messages', [])
                groups = data.get('groups', {})
                ru = data.get('registered_users', {})
                if ru and isinstance(list(ru.values())[0], str):
                    registered_users = {}
                else:
                    registered_users = ru
        except Exception as e:
            print("Error loading DB:", e)

def save_db():
    try:
        with open(DB_FILE, 'w') as f:
            json.dump({
                'messages': messages_db, 
                'groups': groups,
                'registered_users': registered_users
            }, f)
    except Exception as e:
        print("Error saving DB:", e)

load_db()

# ==========================================
# FTP SERVER THREAD
# ==========================================
def start_ftp_server():
    authorizer = DummyAuthorizer()
    authorizer.add_user(FTP_USER, FTP_PASS, FTP_STORAGE, perm="elradfmwMT")
    handler = FTPHandler
    handler.authorizer = authorizer
    server = FTPServer((FTP_HOST, FTP_PORT), handler)
    print(f"[*] FTP Server started on {FTP_HOST}:{FTP_PORT}")
    server.serve_forever()

ftp_thread = threading.Thread(target=start_ftp_server, daemon=True)
ftp_thread.start()

def upload_to_ftp(file_path, filename):
    try:
        ftp = ftplib.FTP()
        ftp.connect(FTP_HOST, FTP_PORT)
        ftp.login(FTP_USER, FTP_PASS)
        with open(file_path, 'rb') as f:
            ftp.storbinary(f'STOR {filename}', f)
        ftp.quit()
        return True
    except Exception as e:
        print(f"FTP Upload Error: {e}")
        return False

def download_from_ftp_memory(filename):
    try:
        ftp = ftplib.FTP()
        ftp.connect(FTP_HOST, FTP_PORT)
        ftp.login(FTP_USER, FTP_PASS)
        bio = io.BytesIO()
        ftp.retrbinary(f'RETR {filename}', bio.write)
        ftp.quit()
        bio.seek(0)
        return bio
    except Exception as e:
        return None

# ==========================================
# HTTP ROUTES
# ==========================================
@app.route('/', methods=['GET'])
def index():
    if 'username' in session:
        return redirect(url_for('chat'))
    return render_template('login.html', show_login=True)

@app.route('/login', methods=['POST'])
def login():
    identifier = request.form.get('identifier', '').strip()
    password = request.form.get('password', '')
    
    if not identifier or not password:
        return render_template('login.html', error="Login: All fields are required.", show_login=True)
        
    target_username = None
    if identifier in registered_users:
        target_username = identifier
    else:
        for u, data in registered_users.items():
            if data['email'] == identifier:
                target_username = u
                break
                
    if not target_username or not check_password_hash(registered_users[target_username]['password'], password):
        return render_template('login.html', error="Login: Invalid credentials.", show_login=True)
        
    session['username'] = target_username
    session['email'] = registered_users[target_username]['email']
    return redirect(url_for('chat'))

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip()
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm_password', '')
    
    if not username or not email or not password:
        return render_template('login.html', error="Register: All fields are required.", show_login=False)
        
    if password != confirm_password:
        return render_template('login.html', error="Register: Passwords do not match.", show_login=False)
        
    if username in registered_users:
        return render_template('login.html', error="Register: Username already taken.", show_login=False)
        
    email_exists = any(u['email'] == email for u in registered_users.values())
    if email_exists:
        return render_template('login.html', error="Register: Email already registered.", show_login=False)
        
    registered_users[username] = {
        'email': email,
        'password': generate_password_hash(password)
    }
    save_db()
    session['username'] = username
    session['email'] = email
    return redirect(url_for('chat'))

@app.route('/chat')
def chat():
    if 'username' not in session:
        return redirect(url_for('index'))
    return render_template('index.html', username=session['username'], email=session['email'])

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('email', None)
    return redirect(url_for('index'))

@app.route('/upload', methods=['POST'])
def upload():
    if 'username' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Empty file"}), 400
        
    file_type = request.form.get('type', 'file')
    ext = os.path.splitext(file.filename)[1]
    if file_type == 'voice': ext = '.webm'
    if not ext: ext = '.bin'
        
    unique_filename = f"{uuid.uuid4().hex}{ext}"
    temp_path = os.path.join(BASE_DIR, unique_filename)
    file.save(temp_path)
    
    success = upload_to_ftp(temp_path, unique_filename)
    if os.path.exists(temp_path):
        os.remove(temp_path)
        
    if success:
        return jsonify({"success": True, "filename": unique_filename, "original_name": file.filename, "type": file_type})
    return jsonify({"error": "FTP upload failed"}), 500

@app.route('/download/<filename>')
def download(filename):
    filename = secure_filename(filename)
    bio = download_from_ftp_memory(filename)
    if bio: return send_file(bio, as_attachment=True, download_name=filename)
    return "File not found", 404

@app.route('/media/<filename>')
def media(filename):
    filename = secure_filename(filename)
    bio = download_from_ftp_memory(filename)
    if bio:
        mimetype = 'audio/webm' if filename.endswith('.webm') else 'application/octet-stream'
        return send_file(bio, mimetype=mimetype)
    return "File not found", 404

# ==========================================
# SOCKET.IO EVENTS
# ==========================================
def broadcast_user_lists():
    active_usernames = list(set(users.values()))
    all_users_data = [{'username': u, 'email': info['email']} for u, info in registered_users.items()]
    emit('user_list', {
        'active': active_usernames,
        'all': all_users_data
    }, broadcast=True)

@socketio.on('connect')
def handle_connect():
    if 'username' in session:
        username = session['username']
        users[request.sid] = username
        
        updated_msgs = []
        for msg in messages_db:
            if msg['recipient'] == username and msg['status'] == 'sent':
                msg['status'] = 'delivered'
                updated_msgs.append(msg)
        if updated_msgs:
            save_db()
            for msg in updated_msgs:
                sender_sids = [sid for sid, u in users.items() if u == msg['sender']]
                for sid in sender_sids:
                    emit('message_status_update', {'id': msg['id'], 'status': 'delivered'}, room=sid)

        broadcast_user_lists()
        user_groups = {gid: g for gid, g in groups.items() if username in g['members']}
        emit('group_list', user_groups)

@socketio.on('disconnect')
def handle_disconnect():
    if request.sid in users:
        del users[request.sid]
        broadcast_user_lists()

@socketio.on('get_history')
def handle_get_history(data):
    chat_id = data.get('chat')
    user = session.get('username')
    
    if chat_id == 'global':
        history = [m for m in messages_db if m['recipient'] == 'global' and user not in m.get('deleted_for', [])]
    elif chat_id in groups:
        history = [m for m in messages_db if m['recipient'] == chat_id and user not in m.get('deleted_for', [])]
    else:
        history = [m for m in messages_db if m['recipient'] in [user, chat_id] and m['sender'] in [user, chat_id] and user not in m.get('deleted_for', [])]
        
    emit('chat_history', history)

@socketio.on('send_message')
def handle_message(data):
    sender = session.get('username')
    recipient = data.get('recipient', 'global')
    message_id = uuid.uuid4().hex
    
    initial_status = 'sent'
    active_usernames = list(set(users.values()))
    if recipient != 'global' and recipient not in groups:
        if recipient in active_usernames:
            initial_status = 'delivered'
    
    message_data = {
        'id': message_id,
        'sender': sender,
        'recipient': recipient,
        'text': data.get('text', ''),
        'type': data.get('type', 'text'),
        'file_url': data.get('file_url', ''),
        'original_name': data.get('original_name', ''),
        'timestamp': time.strftime('%I:%M %p'),
        'deleted': False,
        'status': initial_status
    }
    
    messages_db.append(message_data)
    save_db()
    
    if recipient == 'global':
        emit('receive_message', message_data, broadcast=True)
    elif recipient in groups:
        recipient_sids = [sid for sid, username in users.items() if username in groups[recipient]['members']]
        for sid in recipient_sids:
            emit('receive_message', message_data, room=sid)
    else:
        recipient_sids = [sid for sid, username in users.items() if username in [recipient, sender]]
        for sid in set(recipient_sids):
            emit('receive_message', message_data, room=sid)

@socketio.on('mark_read')
def handle_mark_read(data):
    reader = session.get('username')
    chat_id = data.get('chat')
    
    updated = False
    for msg in messages_db:
        if msg['sender'] == chat_id and msg['recipient'] == reader and msg['status'] in ['sent', 'delivered']:
            msg['status'] = 'read'
            updated = True
            
            sender_sids = [sid for sid, u in users.items() if u == msg['sender']]
            for sid in sender_sids:
                emit('message_status_update', {'id': msg['id'], 'status': 'read'}, room=sid)
                
    if updated:
        save_db()

@socketio.on('delete_message')
def handle_delete_message(data):
    message_id = data.get('id')
    recipient = data.get('recipient')
    
    for msg in messages_db:
        if msg['id'] == message_id:
            msg['deleted'] = True
            break
    save_db()
    
    delete_data = {'id': message_id, 'recipient': recipient}
    
    if recipient == 'global':
        emit('message_deleted', delete_data, broadcast=True)
    elif recipient in groups:
        recipient_sids = [sid for sid, username in users.items() if username in groups[recipient]['members']]
        for sid in recipient_sids:
            emit('message_deleted', delete_data, room=sid)
    else:
        sender = session.get('username')
        recipient_sids = [sid for sid, username in users.items() if username in [recipient, sender]]
        for sid in set(recipient_sids):
            emit('message_deleted', delete_data, room=sid)

@socketio.on('create_group')
def handle_create_group(data):
    group_name = data.get('name')
    members = data.get('members', [])
    sender = session.get('username')
    
    if sender not in members:
        members.append(sender)
        
    group_id = 'group_' + uuid.uuid4().hex
    groups[group_id] = {'name': group_name, 'members': members, 'admin': sender}
    save_db()
    
    recipient_sids = [sid for sid, username in users.items() if username in members]
    for sid in recipient_sids:
        emit('group_created', {'id': group_id, 'name': group_name, 'members': members, 'admin': sender}, room=sid)

@socketio.on('clear_chat')
def handle_clear_chat(data):
    chat_id = data.get('chat')
    user = session.get('username')
    
    for msg in messages_db:
        if chat_id == 'global' and msg['recipient'] == 'global':
            msg.setdefault('deleted_for', []).append(user)
        elif chat_id in groups and msg['recipient'] == chat_id:
            msg.setdefault('deleted_for', []).append(user)
        else:
            if msg['recipient'] in [user, chat_id] and msg['sender'] in [user, chat_id]:
                msg.setdefault('deleted_for', []).append(user)
    save_db()
    emit('chat_cleared', {'chat': chat_id}, room=request.sid)

@socketio.on('delete_group')
def handle_delete_group(data):
    group_id = data.get('id')
    user = session.get('username')
    
    if group_id in groups:
        admin = groups[group_id].get('admin', groups[group_id]['members'][0])
        if admin == user:
            members = groups[group_id]['members']
            del groups[group_id]
            save_db()
            recipient_sids = [sid for sid, u in users.items() if u in members]
            for sid in recipient_sids:
                emit('group_deleted', {'id': group_id}, room=sid)

@socketio.on('kick_member')
def handle_kick_member(data):
    group_id = data.get('group_id')
    target_user = data.get('user')
    user = session.get('username')
    
    if group_id in groups:
        admin = groups[group_id].get('admin', groups[group_id]['members'][0])
        if admin == user and target_user in groups[group_id]['members']:
            groups[group_id]['members'].remove(target_user)
            save_db()
            
            recipient_sids = [sid for sid, u in users.items() if u in groups[group_id]['members'] or u == target_user]
            for sid in recipient_sids:
                emit('member_kicked', {'group_id': group_id, 'user': target_user}, room=sid)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=9090, debug=True, allow_unsafe_werkzeug=True)
