document.addEventListener('DOMContentLoaded', () => {
    const socket = io();
    
    const myUsername = document.getElementById('my-username').dataset.username;
    let currentChat = 'global';
    
    let activeUsersList = [];
    let allUsersList = []; // Array of {username, email}
    let myGroupsList = [];
    
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const attachBtn = document.getElementById('attach-btn');
    const fileInput = document.getElementById('file-input');
    const voiceBtn = document.getElementById('voice-btn');
    const chatList = document.getElementById('chat-list');
    const currentChatName = document.getElementById('current-chat-name');
    const searchInput = document.querySelector('.search-input-wrapper input');
    
    const createGroupIcon = document.getElementById('create-group-icon');
    const createGroupModal = document.getElementById('create-group-modal');
    const groupNameInput = document.getElementById('group-name-input');
    const groupMembersList = document.getElementById('group-members-list');
    const cancelGroupBtn = document.getElementById('cancel-group-btn');
    const confirmGroupBtn = document.getElementById('confirm-group-btn');

    const chatSettingsBtn = document.getElementById('chat-settings-btn');
    const chatSettingsMenu = document.getElementById('chat-settings-menu');
    const clearChatBtn = document.getElementById('clear-chat-btn');
    const deleteGroupBtn = document.getElementById('delete-group-btn');
    const kickMemberBtn = document.getElementById('kick-member-btn');

    let mediaRecorder;
    let audioChunks = [];
    let isRecording = false;

    // SVG Ticks
    const tickSentSVG = `<svg viewBox="0 0 16 15" width="16" height="15"><path fill="currentColor" d="M10.91 3.316l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z"/></svg>`;
    const tickDoubleSVG = `<svg viewBox="0 0 16 15" width="16" height="15"><path fill="currentColor" d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.32.32 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z"/></svg>`;

    function getTickHTML(status, recipient) {
        if (recipient === 'global') return ''; 
        
        let svg = tickSentSVG;
        let cssClass = '';
        if (status === 'delivered') {
            svg = tickDoubleSVG;
        } else if (status === 'read') {
            svg = tickDoubleSVG;
            cssClass = 'tick-read';
        }
        return `<span class="tick-icon ${cssClass}" id="tick-${status}">${svg}</span>`;
    }

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.message-dropdown')) {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Search Filtering logic
    searchInput.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('.chat-list-item').forEach(item => {
            const name = item.querySelector('.chat-name')?.textContent.toLowerCase() || '';
            const email = item.dataset.email?.toLowerCase() || '';
            
            if (item.dataset.chat === 'global' || item.dataset.chat.startsWith('group_')) {
                // For global/groups, search by name only
                if (name.includes(term)) item.style.display = 'flex';
                else item.style.display = 'none';
            } else {
                // For direct chats, search by name OR email
                if (name.includes(term) || email.includes(term)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            }
        });
    });

    messageInput.addEventListener('input', () => {
        if (messageInput.value.trim() !== '') {
            sendBtn.style.display = 'flex';
            voiceBtn.style.display = 'none';
        } else {
            sendBtn.style.display = 'none';
            voiceBtn.style.display = 'flex';
        }
    });

    function sendMessage() {
        const text = messageInput.value.trim();
        if (text) {
            socket.emit('send_message', {
                recipient: currentChat,
                text: text,
                type: 'text'
            });
            messageInput.value = '';
            messageInput.dispatchEvent(new Event('input'));
        }
    }

    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    function renderSingleMessage(data) {
        const isOut = data.sender === myUsername;
        const div = document.createElement('div');
        div.className = `message-bubble ${isOut ? 'message-out' : 'message-in'}`;
        div.dataset.messageId = data.id;
        
        if (data.deleted) {
            div.innerHTML = `
                <div class="message-deleted">
                    <i data-feather="slash"></i>
                    <span>This message was deleted</span>
                </div>
            `;
            chatMessages.appendChild(div);
            return div;
        }

        let contentHtml = '';
        if (data.type === 'text') {
            contentHtml = `<div class="message-text content-wrapper">${escapeHTML(data.text)}</div>`;
        } else if (data.type === 'file') {
            contentHtml = `
                <div class="content-wrapper">
                    <a href="/download/${data.file_url}" class="file-attachment" target="_blank">
                        <div class="file-icon"><i data-feather="file"></i></div>
                        <div class="file-name">${escapeHTML(data.original_name)}</div>
                    </a>
                    ${data.text ? `<div class="message-text">${escapeHTML(data.text)}</div>` : ''}
                </div>
            `;
        } else if (data.type === 'voice') {
            contentHtml = `
                <div class="content-wrapper">
                    <audio class="audio-player" controls>
                        <source src="/media/${data.file_url}" type="audio/webm">
                    </audio>
                </div>
            `;
        }
        
        let dropdownHtml = '';
        let tickHtml = '';
        if (isOut) {
            dropdownHtml = `
                <div class="message-dropdown">
                    <i data-feather="chevron-down"></i>
                    <div class="dropdown-menu">
                        <div class="dropdown-item delete-msg-btn" data-id="${data.id}">Delete for everyone</div>
                    </div>
                </div>
            `;
            tickHtml = getTickHTML(data.status || 'sent', data.recipient);
        }
        
        div.innerHTML = `
            ${!isOut && currentChat !== myUsername && data.recipient !== myUsername ? `<div class="message-sender">${escapeHTML(data.sender)}</div>` : ''}
            ${contentHtml}
            <div class="message-meta">
                <span class="message-time">${data.timestamp}</span>
                <span class="message-tick-container">${tickHtml}</span>
            </div>
            ${dropdownHtml}
        `;
        
        chatMessages.appendChild(div);
        
        if (isOut) {
            const dropdownToggle = div.querySelector('.message-dropdown i');
            const menu = div.querySelector('.dropdown-menu');
            dropdownToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                document.querySelectorAll('.dropdown-menu').forEach(m => {
                    if (m !== menu) m.classList.remove('show');
                });
                menu.classList.toggle('show');
            });
            
            div.querySelector('.delete-msg-btn').addEventListener('click', () => {
                socket.emit('delete_message', { id: data.id, recipient: data.recipient });
            });
        } else {
            if (data.recipient === myUsername || data.recipient === currentChat) {
                if (data.status !== 'read') {
                    socket.emit('mark_read', { chat: data.sender });
                }
            }
        }
        
        return div;
    }

    socket.on('receive_message', (data) => {
        let shouldRender = false;
        if (data.recipient === 'global' && currentChat === 'global') {
            shouldRender = true;
        } else if (data.recipient.startsWith('group_')) {
            if (currentChat === data.recipient) shouldRender = true;
        } else {
            if (currentChat === data.sender || currentChat === data.recipient) shouldRender = true;
        }

        if (shouldRender) {
            renderSingleMessage(data);
            feather.replace();
            scrollToBottom();
        }
    });

    socket.on('message_status_update', (data) => {
        const msgBubble = document.querySelector(`.message-bubble[data-message-id="${data.id}"]`);
        if (msgBubble) {
            const tickContainer = msgBubble.querySelector('.message-tick-container');
            if (tickContainer) {
                tickContainer.innerHTML = getTickHTML(data.status, 'user');
            }
        }
    });

    socket.on('message_deleted', (data) => {
        const msgBubble = document.querySelector(`.message-bubble[data-message-id="${data.id}"]`);
        if (msgBubble) {
            msgBubble.innerHTML = `
                <div class="message-deleted">
                    <i data-feather="slash"></i>
                    <span>This message was deleted</span>
                </div>
            `;
            feather.replace();
        }
    });

    socket.on('chat_history', (history) => {
        let displayName = currentChat === 'global' ? 'Global Chat' : currentChat;
        if (currentChat.startsWith('group_')) {
            const g = myGroupsList.find(x => x.id === currentChat);
            if (g) displayName = g.name;
        }
        
        chatMessages.innerHTML = `<div class="system-message"><span><i data-feather="lock" style="width: 12px; height: 12px;"></i> Secure chat loaded with ${escapeHTML(displayName)}</span></div>`;
        
        history.forEach(msg => {
            renderSingleMessage(msg);
        });
        
        feather.replace();
        scrollToBottom();
        
        if (!currentChat.startsWith('group_') && currentChat !== 'global') {
            socket.emit('mark_read', { chat: currentChat });
        }
    });

    function requestHistory() {
        socket.emit('get_history', { chat: currentChat });
    }

    function renderChatList() {
        let globalActive = currentChat === 'global' ? 'active' : '';
        let html = `
            <div class="chat-list-item ${globalActive}" data-chat="global">
                <div class="avatar group-avatar"><i data-feather="globe"></i></div>
                <div class="chat-info">
                    <div class="chat-name">Global Chat</div>
                    <div class="chat-preview">Everyone in the server</div>
                </div>
            </div>
        `;
        
        myGroupsList.forEach(g => {
            let active = currentChat === g.id ? 'active' : '';
            html += `
                <div class="chat-list-item ${active}" data-chat="${g.id}">
                    <div class="avatar group-avatar"><i data-feather="users"></i></div>
                    <div class="chat-info">
                        <div class="chat-name">${escapeHTML(g.name)}</div>
                        <div class="chat-preview">${g.members.length} members</div>
                    </div>
                </div>
            `;
        });
        
        allUsersList.forEach(userObj => {
            const user = userObj.username;
            const email = userObj.email;
            
            if (user !== myUsername) {
                let active = currentChat === user ? 'active' : '';
                let isOnline = activeUsersList.includes(user);
                let statusClass = isOnline ? 'status-online' : 'status-offline';
                let statusText = isOnline ? 'Online' : 'Offline';
                
                html += `
                    <div class="chat-list-item ${active}" data-chat="${escapeHTML(user)}" data-email="${escapeHTML(email)}">
                        <div class="avatar">${user[0].toUpperCase()}</div>
                        <div class="chat-info">
                            <div class="chat-name">
                                ${escapeHTML(user)}
                                <span class="status-indicator ${statusClass}"></span>
                            </div>
                            <div class="chat-preview" style="display:flex; justify-content:space-between;">
                                <span>${statusText}</span>
                                <span style="font-size:10px; color:var(--text-secondary);">${escapeHTML(email)}</span>
                            </div>
                        </div>
                    </div>
                `;
            }
        });
        
        chatList.innerHTML = html;
        feather.replace();
        
        document.querySelectorAll('.chat-list-item').forEach(item => {
            item.addEventListener('click', () => {
                document.querySelectorAll('.chat-list-item').forEach(i => i.classList.remove('active'));
                item.classList.add('active');
                currentChat = item.dataset.chat;
                
                let displayName = currentChat;
                let isGroupAdmin = false;
                if (currentChat === 'global') {
                    displayName = 'Global Chat';
                } else if (currentChat.startsWith('group_')) {
                    const g = myGroupsList.find(x => x.id === currentChat);
                    if (g) {
                        displayName = g.name;
                        if (g.admin === myUsername) isGroupAdmin = true;
                    }
                }
                currentChatName.textContent = displayName;
                
                if (isGroupAdmin) {
                    deleteGroupBtn.style.display = 'block';
                    kickMemberBtn.style.display = 'block';
                } else {
                    deleteGroupBtn.style.display = 'none';
                    kickMemberBtn.style.display = 'none';
                }
                
                requestHistory();
            });
        });
        
        // Re-apply search filter
        searchInput.dispatchEvent(new Event('input'));
    }

    socket.on('connect', () => {
        requestHistory();
    });

    socket.on('user_list', (data) => {
        activeUsersList = data.active;
        allUsersList = data.all;
        renderChatList();
    });

    socket.on('group_list', (groups) => {
        myGroupsList = Object.keys(groups).map(k => ({id: k, name: groups[k].name, members: groups[k].members, admin: groups[k].admin}));
        renderChatList();
    });

    socket.on('group_created', (data) => {
        myGroupsList.push({id: data.id, name: data.name, members: data.members, admin: data.admin});
        renderChatList();
    });

    socket.on('chat_cleared', (data) => {
        if (data.chat === currentChat) requestHistory();
    });

    socket.on('group_deleted', (data) => {
        myGroupsList = myGroupsList.filter(g => g.id !== data.id);
        if (currentChat === data.id) {
            currentChat = 'global';
            currentChatName.textContent = 'Global Chat';
            requestHistory();
        }
        renderChatList();
    });

    socket.on('member_kicked', (data) => {
        if (data.user === myUsername) {
            alert("You have been kicked from the group.");
            myGroupsList = myGroupsList.filter(g => g.id !== data.group_id);
            if (currentChat === data.group_id) {
                currentChat = 'global';
                currentChatName.textContent = 'Global Chat';
                requestHistory();
            }
            renderChatList();
        } else {
            const g = myGroupsList.find(x => x.id === data.group_id);
            if (g) {
                g.members = g.members.filter(m => m !== data.user);
                renderChatList();
            }
        }
    });

    chatSettingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chatSettingsMenu.classList.toggle('show');
    });

    clearChatBtn.addEventListener('click', () => {
        if (confirm("Are you sure you want to clear the chat history?")) {
            socket.emit('clear_chat', { chat: currentChat });
            chatSettingsMenu.classList.remove('show');
        }
    });

    deleteGroupBtn.addEventListener('click', () => {
        if (confirm("Are you sure you want to delete this group?")) {
            socket.emit('delete_group', { id: currentChat });
            chatSettingsMenu.classList.remove('show');
        }
    });

    kickMemberBtn.addEventListener('click', () => {
        const g = myGroupsList.find(x => x.id === currentChat);
        if (!g) return;
        
        let target = prompt("Enter the exact username of the member to kick:\n" + g.members.filter(m => m !== myUsername).join(', '));
        if (target && g.members.includes(target)) {
            socket.emit('kick_member', { group_id: currentChat, user: target });
        } else if (target) {
            alert("User not found in group.");
        }
        chatSettingsMenu.classList.remove('show');
    });

    createGroupIcon.addEventListener('click', (e) => {
        e.preventDefault();
        groupNameInput.value = '';
        let membersHtml = '';
        allUsersList.forEach(userObj => {
            const user = userObj.username;
            if (user !== myUsername) {
                let isOnline = activeUsersList.includes(user);
                let badge = isOnline ? '<span style="color:var(--accent); font-size:11px; margin-left:5px;">(Online)</span>' : '';
                membersHtml += `
                    <label class="member-checkbox">
                        <input type="checkbox" value="${escapeHTML(user)}">
                        ${escapeHTML(user)} ${badge}
                    </label>
                `;
            }
        });
        if (membersHtml === '') membersHtml = '<div style="font-size:13px;color:var(--text-secondary);">No other users available</div>';
        groupMembersList.innerHTML = membersHtml;
        createGroupModal.classList.add('show');
    });

    cancelGroupBtn.addEventListener('click', () => createGroupModal.classList.remove('show'));

    confirmGroupBtn.addEventListener('click', () => {
        const name = groupNameInput.value.trim();
        if (!name) return alert("Please enter a group name");
        const selectedMembers = [];
        groupMembersList.querySelectorAll('input:checked').forEach(cb => selectedMembers.push(cb.value));
        if (selectedMembers.length === 0) return alert("Select at least one member");
        socket.emit('create_group', { name: name, members: selectedMembers });
        createGroupModal.classList.remove('show');
    });

    attachBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', async () => {
        if (fileInput.files.length > 0) {
            await uploadFile(fileInput.files[0], 'file');
            fileInput.value = '';
        }
    });

    voiceBtn.addEventListener('click', async () => {
        if (!isRecording) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
                mediaRecorder.onstop = async () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    audioChunks = [];
                    const audioFile = new File([audioBlob], "voice_note.webm", { type: 'audio/webm' });
                    await uploadFile(audioFile, 'voice');
                };
                mediaRecorder.start();
                isRecording = true;
                voiceBtn.classList.add('recording');
                voiceBtn.innerHTML = '<i data-feather="square"></i>';
                feather.replace();
            } catch (err) {
                console.error("Mic Error:", err);
                alert("Microphone access denied or unavailable.\n\nMake sure your browser has permission and you are accessing the site via 'localhost' or an 'HTTPS' Cloudflare tunnel. Browsers block microphone access on normal HTTP IP addresses.");
            }
        } else {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
            isRecording = false;
            voiceBtn.classList.remove('recording');
            voiceBtn.innerHTML = '<i data-feather="mic"></i>';
            feather.replace();
        }
    });

    async function uploadFile(file, type) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        try {
            const response = await fetch('/upload', { method: 'POST', body: formData });
            const result = await response.json();
            
            if (result.success) {
                socket.emit('send_message', {
                    recipient: currentChat,
                    text: type === 'file' ? 'Sent a file' : '',
                    type: result.type,
                    file_url: result.filename,
                    original_name: result.original_name
                });
            } else {
                alert("Upload failed: " + result.error);
            }
        } catch (err) {
            alert("Error uploading file.");
        }
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }
});
